package com.example.oivinstaller;

import android.os.ParcelFileDescriptor;

// Runs inside the Shizuku (shell) process so it can reach Android/data.
interface IFileService {
    void destroy() = 16777114;
    boolean exists(String path) = 1;
    boolean mkdirs(String path) = 2;
    boolean delete(String path) = 3;
    String[] list(String path) = 4;
    ParcelFileDescriptor openRead(String path) = 5;
    ParcelFileDescriptor openWrite(String path) = 6;
}
