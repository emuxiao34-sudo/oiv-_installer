package com.example.oivinstaller

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.min

/** Floating "MODS" bubble. Tap it to open a panel with an on/off switch for every mod. */
class OverlayService : Service() {

    companion object {
        var running by mutableStateOf(false)
        private const val CHANNEL = "mod_menu"
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var bubble: View? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var rows: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var statusView: TextView? = null
    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(
                this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
            )
        } else {
            startForeground(1, n)
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        showBubble()
        running = true
    }

    override fun onDestroy() {
        running = false
        runCatching { bubble?.let { wm.removeView(it) } }
        runCatching { panel?.let { wm.removeView(it) } }
        bubble = null
        panel = null
        io.shutdown()
        super.onDestroy()
    }

    // ---------- bubble ----------

    private fun showBubble() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        if (bubble != null) return

        val tv = TextView(this).apply {
            text = "MODS"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xE6161B26.toInt())
                setStroke(dp(2), 0xFF4C8DFF.toInt())
            }
        }
        val lp = bubbleLp ?: WindowManager.LayoutParams(
            dp(54), dp(54),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(220)
        }
        bubbleLp = lp

        tv.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x
                        startY = lp.y
                        touchX = e.rawX
                        touchY = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - touchX).toInt()
                        val dy = (e.rawY - touchY).toInt()
                        if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                        if (moved) {
                            lp.x = startX + dx
                            lp.y = startY + dy
                            wm.updateViewLayout(v, lp)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) showPanel()
                }
                return true
            }
        })
        wm.addView(tv, lp)
        bubble = tv
    }

    // ---------- panel ----------

    private fun showPanel() {
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        if (panel != null) return

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(0xF0161B26.toInt())
            }
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            TextView(this).apply {
                text = "Mods"
                textSize = 17f
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
            },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f),
        )
        header.addView(
            TextView(this).apply {
                text = "–"
                textSize = 24f
                setTextColor(Color.WHITE)
                setPadding(dp(14), 0, dp(4), 0)
                setOnClickListener { showBubble() }
            },
        )
        box.addView(header)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(list) }
        box.addView(
            sv,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            ),
        )

        val status = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFFB8C2D6.toInt())
            setPadding(0, dp(8), 0, 0)
            text = "Restart the game after changing mods."
        }
        box.addView(status)

        rows = list
        scroll = sv
        statusView = status

        val width = min(dp(300), resources.displayMetrics.widthPixels - dp(24))
        val lp = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.CENTER }
        wm.addView(box, lp)
        panel = box
        refreshRows()
    }

    private fun refreshRows() {
        val list = rows ?: return
        list.removeAllViews()
        val mods = ModStore.get(this).list()

        scroll?.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            if (mods.size > 5) dp(320) else LinearLayout.LayoutParams.WRAP_CONTENT,
        )

        if (mods.isEmpty()) {
            list.addView(
                TextView(this).apply {
                    text = "No mods yet. Add one in the app."
                    setTextColor(Color.WHITE)
                    setPadding(0, dp(10), 0, dp(10))
                },
            )
            return
        }
        for (m in mods) {
            val sw = Switch(this).apply {
                text = m.name
                isChecked = m.enabled
                isEnabled = !busy
                setTextColor(Color.WHITE)
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { toggle(m, isChecked) }
            }
            list.addView(
                sw,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                ),
            )
        }
    }

    private fun toggle(m: Mod, on: Boolean) {
        if (busy) return
        busy = true
        statusView?.text = "Working…"
        refreshRows()
        io.execute {
            val msg = try {
                val store = ModStore.get(this)
                val root = (store.activeRoot() ?: Prefs.modsPath(this)).trimEnd('/')
                val fs = Backends.open(root)
                if (on) store.enable(m.id, fs, root) else store.disable(m.id, fs, root)
                "${m.name}: ${if (on) "ON" else "OFF"}. Restart the game."
            } catch (e: Exception) {
                "Failed: ${e.message}"
            }
            main.post {
                busy = false
                statusView?.text = msg
                refreshRows()
            }
        }
    }

    // ---------- notification ----------

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Floating mod menu", NotificationManager.IMPORTANCE_LOW),
        )
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Floating mod menu is on")
            .setContentText("Tap to open the app")
            .setContentIntent(open)
            .addAction(0, "Close menu", stop)
            .setOngoing(true)
            .build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
