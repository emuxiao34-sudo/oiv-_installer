package com.example.oivinstaller

import android.os.ParcelFileDescriptor
import java.io.File
import kotlin.system.exitProcess

/**
 * Started by Shizuku in a shell-privileged process. Only touches paths under
 * /storage/emulated/0/ so a bug here can't wander through the rest of the system.
 */
class FileService : IFileService.Stub() {

    private fun checked(path: String): File {
        if (!path.startsWith("/storage/emulated/0/") || path.contains("..")) {
            throw SecurityException("Path not allowed: $path")
        }
        return File(path)
    }

    override fun destroy() {
        exitProcess(0)
    }

    override fun exists(path: String): Boolean = checked(path).exists()

    override fun mkdirs(path: String): Boolean = checked(path).let { it.isDirectory || it.mkdirs() }

    override fun delete(path: String): Boolean = checked(path).delete()

    override fun list(path: String): Array<String>? = checked(path).list()

    override fun openRead(path: String): ParcelFileDescriptor? {
        val f = checked(path)
        return if (f.isFile) ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY) else null
    }

    override fun openWrite(path: String): ParcelFileDescriptor {
        val f = checked(path)
        f.parentFile?.mkdirs()
        return ParcelFileDescriptor.open(
            f,
            ParcelFileDescriptor.MODE_WRITE_ONLY or
                ParcelFileDescriptor.MODE_CREATE or
                ParcelFileDescriptor.MODE_TRUNCATE,
        )
    }
}
