package com.example.oivinstaller

import android.app.Application

class OivApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ShizukuLink.init(this)
    }
}
