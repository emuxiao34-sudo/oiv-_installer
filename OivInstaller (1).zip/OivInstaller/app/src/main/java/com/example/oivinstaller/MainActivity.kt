package com.example.oivinstaller

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { MainScreen(resumeTick.intValue) } }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue++
        ShizukuLink.refresh()
    }
}

private fun hasStorageAccess(ctx: Context): Boolean =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Environment.isExternalStorageManager()
    else ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
        PackageManager.PERMISSION_GRANTED

private fun displayNameOf(ctx: Context, uri: Uri): String =
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) c.getString(i) else null
    } ?: "mod"

@Composable
private fun MainScreen(resumeTick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { ModStore.get(ctx) }

    var modsPath by remember { mutableStateOf(Prefs.modsPath(ctx)) }
    var log by remember { mutableStateOf("Add a .oiv or .zip mod to get started.") }
    var busy by remember { mutableStateOf(false) }

    val tick = ModStore.changes.intValue
    val mods = remember(tick) { store.list() }
    val locked = remember(tick) { store.activeRoot() != null }
    val shizuku = ShizukuLink.status
    val protectedPath = Backends.isProtected(modsPath)
    val overlayOk = remember(resumeTick) { Settings.canDrawOverlays(ctx) }
    val storageOk = remember(resumeTick) { hasStorageAccess(ctx) }
    val menuOn = OverlayService.running

    fun launchWork(start: String, work: () -> String) {
        scope.launch {
            busy = true
            log = start
            log = try {
                withContext(Dispatchers.IO) { work() }
            } catch (e: Exception) {
                "Failed: ${e.message}"
            }
            busy = false
        }
    }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            launchWork("Importing…") {
                if (modsPath.isBlank()) throw IllegalStateException("Set the mods folder first.")
                val r = OivInstaller.import(ctx, uri, displayNameOf(ctx, uri))
                store.register(Mod(r.id, r.name, r.files, false))
                val root = (store.activeRoot() ?: modsPath.trim()).trimEnd('/')
                val note = try {
                    store.enable(r.id, Backends.open(root), root)
                    "Installed and turned on"
                } catch (e: Exception) {
                    "Imported, but couldn't turn it on (${e.message})"
                }
                buildString {
                    append("$note \"${r.name}\": ${r.files.size} file(s).")
                    if (r.skipped.isNotEmpty()) {
                        append("\n\nSkipped ${r.skipped.size}:\n")
                        append(r.skipped.take(15).joinToString("\n") { "• $it" })
                        if (r.skipped.size > 15) append("\n…and ${r.skipped.size - 15} more")
                    }
                }
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("OIV / ZIP Mod Installer", style = MaterialTheme.typography.headlineSmall)

        // ----- folder -----
        OutlinedTextField(
            value = modsPath,
            onValueChange = {
                modsPath = it
                Prefs.setModsPath(ctx, it)
            },
            enabled = !locked,
            label = { Text("Game mods folder") },
            supportingText = {
                if (locked) Text("Turn off all mods to change this.")
            },
            modifier = Modifier.fillMaxWidth(),
        )

        // ----- access -----
        if (protectedPath) {
            when (shizuku) {
                ShizukuLink.Status.CONNECTED -> Text("Shizuku: connected ✓")
                ShizukuLink.Status.CONNECTING -> Text("Shizuku: connecting…")
                ShizukuLink.Status.NEEDS_PERMISSION -> {
                    Text("This folder is inside Android/data, so the app needs Shizuku permission.")
                    Button(onClick = { ShizukuLink.requestPermission() }) { Text("Allow Shizuku access") }
                }
                ShizukuLink.Status.NOT_RUNNING -> {
                    Text(
                        "Shizuku isn't running. Open the Shizuku app and start it " +
                            "(on Android 11+ use Wireless debugging), then come back here.",
                    )
                    OutlinedButton(onClick = {
                        val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                        if (i != null) ctx.startActivity(i)
                        else log = "Shizuku isn't installed. Get it from shizuku.rikka.app"
                    }) { Text("Open Shizuku") }
                }
            }
        } else if (!storageOk) {
            Text("Storage access is needed for this folder.")
            Button(onClick = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    ctx.startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:${ctx.packageName}"),
                        ),
                    )
                }
            }) { Text("Grant storage access") }
        }

        // ----- install -----
        Button(
            onClick = { picker.launch(arrayOf("*/*")) },
            enabled = !busy && modsPath.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Add mod (.oiv or .zip)") }

        Text(log)

        // ----- floating menu -----
        HorizontalDivider()
        Text("Floating menu", style = MaterialTheme.typography.titleMedium)
        if (!overlayOk) {
            Text("Allow \"Display over other apps\" so the menu can float above the game.")
            Button(onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")),
                )
            }) { Text("Allow overlay") }
        } else {
            Button(
                onClick = {
                    val svc = Intent(ctx, OverlayService::class.java)
                    if (menuOn) {
                        ctx.stopService(svc)
                    } else {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
                            PackageManager.PERMISSION_GRANTED
                        ) {
                            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        ContextCompat.startForegroundService(ctx, svc)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (menuOn) "Hide floating menu" else "Show floating menu") }
        }

        // ----- mods -----
        HorizontalDivider()
        Text("Your mods", style = MaterialTheme.typography.titleMedium)
        if (mods.isEmpty()) Text("No mods yet.")
        mods.forEach { m ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(m.name)
                    Text("${m.files.size} file(s)", style = MaterialTheme.typography.bodySmall)
                }
                Switch(
                    checked = m.enabled,
                    enabled = !busy,
                    onCheckedChange = { on ->
                        launchWork(if (on) "Turning on…" else "Turning off…") {
                            val root = (store.activeRoot() ?: modsPath.trim()).trimEnd('/')
                            val fs = Backends.open(root)
                            if (on) store.enable(m.id, fs, root) else store.disable(m.id, fs, root)
                            "${m.name} is now ${if (on) "ON" else "OFF"}. Restart the game."
                        }
                    },
                )
                TextButton(
                    enabled = !busy && !m.enabled,
                    onClick = {
                        launchWork("Deleting…") {
                            store.delete(m.id)
                            "Deleted ${m.name}."
                        }
                    },
                ) { Text("Delete") }
            }
        }
    }
}
