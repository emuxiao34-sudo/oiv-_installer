package com.example.oivinstaller

import android.content.Context
import androidx.compose.runtime.mutableIntStateOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Mod(val id: String, val name: String, val files: List<String>, val enabled: Boolean)

/**
 * Keeps every imported mod's files inside the app ("library") so a mod can be switched
 * on and off at any time.
 *
 *  - Turning a mod ON saves the original game file (once) and copies the mod's file over it.
 *  - Turning it OFF puts the original back, or deletes the file if the game never had it.
 *  - If two mods touch the same file, the most recently turned-on one wins; turning it off
 *    falls back to the next one, then to the original.
 */
class ModStore private constructor(ctx: Context) {

    companion object {
        /** Compose watches this to refresh lists after any change. */
        val changes = mutableIntStateOf(0)

        @Volatile
        private var instance: ModStore? = null

        fun get(ctx: Context): ModStore =
            instance ?: synchronized(this) {
                instance ?: ModStore(ctx.applicationContext).also { instance = it }
            }
    }

    private class Entry(
        val id: String,
        val name: String,
        val files: List<String>,
        var enabled: Boolean,
    )

    private val base = File(ctx.filesDir, "modstore").apply { mkdirs() }
    private val stateFile = File(base, "state.json")

    private val entries = mutableListOf<Entry>()
    private val owners = linkedMapOf<String, MutableList<String>>()
    private val orig = hashMapOf<String, Boolean>() // rel -> game already had this file
    private var gameRoot: String? = null

    init {
        load()
    }

    // ---------- reading ----------

    @Synchronized
    fun list(): List<Mod> = entries.map { Mod(it.id, it.name, it.files, it.enabled) }

    /** The mods folder currently in use, or null when every mod is off. */
    @Synchronized
    fun activeRoot(): String? = gameRoot

    // ---------- importing ----------

    @Synchronized
    fun newModDir(): Pair<String, File> {
        val id = "m" + System.currentTimeMillis().toString(36)
        val dir = File(base, "library/$id/payload")
        dir.mkdirs()
        return id to dir
    }

    @Synchronized
    fun discardModDir(id: String) {
        File(base, "library/$id").deleteRecursively()
    }

    @Synchronized
    fun register(mod: Mod) {
        entries += Entry(mod.id, mod.name, mod.files, false)
        save()
    }

    @Synchronized
    fun delete(id: String) {
        val e = entries.firstOrNull { it.id == id } ?: return
        if (e.enabled) throw IllegalStateException("Turn the mod off first.")
        entries.remove(e)
        File(base, "library/$id").deleteRecursively()
        save()
    }

    // ---------- on / off ----------

    @Synchronized
    fun enable(id: String, fs: GameFs, root: String) {
        val mod = entries.firstOrNull { it.id == id } ?: throw IllegalStateException("Mod not found")
        if (mod.enabled) return
        val r = root.trimEnd('/')
        if (gameRoot != null && gameRoot != r) {
            throw IllegalStateException("Turn off all mods before changing the mods folder.")
        }
        gameRoot = r

        val done = mutableListOf<String>()
        try {
            for (rel in mod.files) {
                val target = "$r/$rel"
                val list = owners.getOrPut(rel) { mutableListOf() }
                if (list.isEmpty()) {
                    if (fs.exists(target)) {
                        val saved = File(base, "orig/$rel")
                        saved.parentFile?.mkdirs()
                        val input = fs.openRead(target)
                            ?: throw IllegalStateException("Can't read $rel")
                        input.use { i -> saved.outputStream().use { i.copyTo(it) } }
                        orig[rel] = true
                    } else {
                        orig[rel] = false
                    }
                }
                list.add(id)
                done += rel
                copyPayload(id, rel, fs, target)
            }
            mod.enabled = true
        } catch (e: Exception) {
            for (rel in done.asReversed()) runCatching { release(id, rel, fs, r) }
            throw e
        } finally {
            cleanup()
            if (owners.isEmpty()) gameRoot = null
            save()
        }
    }

    @Synchronized
    fun disable(id: String, fs: GameFs, root: String) {
        val mod = entries.firstOrNull { it.id == id } ?: return
        if (!mod.enabled) return
        val r = (gameRoot ?: root).trimEnd('/')
        try {
            for (rel in mod.files) release(id, rel, fs, r)
            mod.enabled = false
        } finally {
            cleanup()
            if (owners.isEmpty()) gameRoot = null
            save()
        }
    }

    // ---------- internals ----------

    private fun release(id: String, rel: String, fs: GameFs, root: String) {
        val list = owners[rel] ?: return
        if (id !in list) return
        val target = "$root/$rel"

        if (list.last() == id) {
            val remaining = list.filter { it != id }
            if (remaining.isNotEmpty()) {
                copyPayload(remaining.last(), rel, fs, target)
            } else {
                val saved = File(base, "orig/$rel")
                if (orig[rel] == true && saved.exists()) {
                    saved.inputStream().use { i -> fs.openWrite(target).use { i.copyTo(it) } }
                } else {
                    fs.delete(target)
                    prune(fs, root, target)
                }
                saved.delete()
                orig.remove(rel)
            }
        }
        list.remove(id)
        if (list.isEmpty()) owners.remove(rel)
    }

    private fun copyPayload(id: String, rel: String, fs: GameFs, target: String) {
        File(base, "library/$id/payload/$rel").inputStream()
            .use { i -> fs.openWrite(target).use { i.copyTo(it) } }
    }

    private fun prune(fs: GameFs, root: String, target: String) {
        var p = target.substringBeforeLast('/', "")
        while (p.length > root.length && p.startsWith(root)) {
            val children = fs.listDir(p)
            if (children != null && children.isEmpty()) {
                fs.delete(p)
                p = p.substringBeforeLast('/', "")
            } else {
                break
            }
        }
    }

    private fun cleanup() {
        owners.entries.removeAll { it.value.isEmpty() }
        val stale = orig.keys.filter { it !in owners }
        for (rel in stale) {
            orig.remove(rel)
            File(base, "orig/$rel").delete()
        }
    }

    private fun save() {
        val json = JSONObject()
        json.put("root", gameRoot ?: JSONObject.NULL)
        json.put(
            "mods",
            JSONArray().also { arr ->
                for (e in entries) {
                    arr.put(
                        JSONObject()
                            .put("id", e.id)
                            .put("name", e.name)
                            .put("enabled", e.enabled)
                            .put("files", JSONArray(e.files)),
                    )
                }
            },
        )
        json.put(
            "owners",
            JSONObject().also { o -> for ((k, v) in owners) o.put(k, JSONArray(v)) },
        )
        json.put(
            "orig",
            JSONObject().also { o -> for ((k, v) in orig) o.put(k, v) },
        )
        stateFile.writeText(json.toString())
        changes.intValue++
    }

    private fun load() {
        if (!stateFile.exists()) return
        runCatching {
            val json = JSONObject(stateFile.readText())
            gameRoot = if (json.isNull("root")) null else json.getString("root")
            val mods = json.getJSONArray("mods")
            for (i in 0 until mods.length()) {
                val m = mods.getJSONObject(i)
                val files = m.getJSONArray("files")
                entries += Entry(
                    m.getString("id"),
                    m.getString("name"),
                    (0 until files.length()).map { files.getString(it) },
                    m.getBoolean("enabled"),
                )
            }
            val o = json.getJSONObject("owners")
            for (k in o.keys()) {
                val a = o.getJSONArray(k)
                owners[k] = (0 until a.length()).map { a.getString(it) }.toMutableList()
            }
            val og = json.getJSONObject("orig")
            for (k in og.keys()) orig[k] = og.getBoolean(k)
        }
    }
}
