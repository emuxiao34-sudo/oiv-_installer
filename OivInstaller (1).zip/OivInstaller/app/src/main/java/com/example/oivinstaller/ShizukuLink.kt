package com.example.oivinstaller

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import rikka.shizuku.Shizuku

/** Keeps the connection to Shizuku and to our file service alive for the whole app process. */
object ShizukuLink {

    enum class Status { NOT_RUNNING, NEEDS_PERMISSION, CONNECTING, CONNECTED }

    var status by mutableStateOf(Status.NOT_RUNNING)
        private set

    @Volatile
    var service: IFileService? = null
        private set

    private var appContext: Context? = null
    private var binding = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = IFileService.Stub.asInterface(binder)
            binding = false
            status = Status.CONNECTED
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            binding = false
            refresh()
        }
    }

    fun init(context: Context) {
        appContext = context.applicationContext
        Shizuku.addBinderReceivedListenerSticky { refresh() }
        Shizuku.addBinderDeadListener {
            service = null
            binding = false
            refresh()
        }
        Shizuku.addRequestPermissionResultListener { _, _ -> refresh() }
    }

    fun refresh() {
        val ctx = appContext ?: return
        if (service != null) {
            status = Status.CONNECTED
            return
        }
        val running = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        if (!running) {
            status = Status.NOT_RUNNING
            return
        }
        val granted = runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
        if (!granted) {
            status = Status.NEEDS_PERMISSION
            return
        }
        status = Status.CONNECTING
        if (!binding) {
            binding = true
            try {
                val args = Shizuku.UserServiceArgs(
                    ComponentName(ctx.packageName, FileService::class.java.name),
                )
                    .daemon(false)
                    .processNameSuffix("files")
                    .debuggable(false)
                    .version(1)
                Shizuku.bindUserService(args, connection)
            } catch (e: Exception) {
                binding = false
                status = Status.NOT_RUNNING
            }
        }
    }

    fun requestPermission() {
        runCatching { Shizuku.requestPermission(1001) }
    }
}
