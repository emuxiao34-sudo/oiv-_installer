package com.example.oivinstaller

import android.content.Context
import android.net.Uri
import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import javax.xml.parsers.DocumentBuilderFactory

class ImportResult(
    val id: String,
    val name: String,
    val files: List<String>,
    val skipped: List<String>,
)

private class Collected(val name: String, val files: List<String>, val skipped: List<String>)

private class Op(val kind: String, val archive: String, val source: String?, val target: String)

/**
 * Turns a .oiv or .zip into a mod in the app's library. Nothing touches the game folder here;
 * that happens when the mod is switched on (see ModStore).
 */
object OivInstaller {

    fun import(context: Context, uri: Uri, displayName: String): ImportResult {
        val temp = File(context.cacheDir, "incoming.zip")
        context.contentResolver.openInputStream(uri)!!.use { input ->
            temp.outputStream().use { input.copyTo(it) }
        }
        val store = ModStore.get(context)
        val (id, payloadDir) = store.newModDir()
        try {
            return ZipFile(temp).use { zip ->
                val entries = zip.entries().asSequence().filter { !it.isDirectory }.toList()
                val byName = entries.associateBy { norm(it.name).lowercase() }
                val manifest = byName["assembly.xml"]

                val collected = if (manifest != null) {
                    fromOiv(zip, manifest, byName, displayName, payloadDir)
                } else {
                    fromPlainZip(zip, entries, displayName, payloadDir)
                }
                if (collected.files.isEmpty()) {
                    val why = collected.skipped.take(5).joinToString("; ")
                    throw IllegalStateException(
                        "Nothing to install." + if (why.isNotEmpty()) " Skipped: $why" else "",
                    )
                }
                ImportResult(id, collected.name, collected.files, collected.skipped)
            }
        } catch (e: Exception) {
            store.discardModDir(id)
            throw e
        } finally {
            temp.delete()
        }
    }

    // ---------- .oiv ----------

    private fun fromOiv(
        zip: ZipFile,
        manifest: ZipEntry,
        byName: Map<String, ZipEntry>,
        displayName: String,
        payloadDir: File,
    ): Collected {
        val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
            .parse(zip.getInputStream(manifest))
        val root = doc.documentElement
        val name = root.getElementsByTagName("name").item(0)?.textContent?.trim()
            ?.takeIf { it.isNotEmpty() } ?: displayName

        val ops = mutableListOf<Op>()
        val skipped = mutableListOf<String>()
        val content = root.getElementsByTagName("content").item(0) as? Element
        if (content != null) walk(content, "", ops, skipped)

        val files = LinkedHashSet<String>()
        for (op in ops) {
            val rel = norm(join(op.archive, op.target))
            when (op.kind) {
                "add", "replace" -> {
                    val src = op.source?.let { s ->
                        val key = norm(s).lowercase()
                        byName["content/$key"] ?: byName[key]
                    }
                    when {
                        src == null -> skipped += "missing source in package: ${op.source}"
                        put(zip, src, payloadDir, rel) -> files += rel
                        else -> skipped += "unsafe path: $rel"
                    }
                }
                "delete" -> skipped += "delete not applied (original files are left alone): $rel"
            }
        }
        return Collected(name, files.toList(), skipped)
    }

    private fun walk(parent: Element, prefix: String, ops: MutableList<Op>, skipped: MutableList<String>) {
        var node: Node? = parent.firstChild
        while (node != null) {
            if (node is Element) {
                when (node.tagName.lowercase()) {
                    "archive" -> walk(node, join(prefix, node.getAttribute("path")), ops, skipped)
                    "add", "replace" -> ops += Op(
                        node.tagName.lowercase(), prefix, node.getAttribute("source"), node.textContent.trim(),
                    )
                    "delete" -> ops += Op("delete", prefix, null, node.textContent.trim())
                    else -> skipped += "<${node.tagName}> edit not supported" +
                        (node.getAttribute("path").takeIf { it.isNotEmpty() }?.let { " ($it)" } ?: "")
                }
            }
            node = node.nextSibling
        }
    }

    // ---------- plain .zip ----------

    private fun fromPlainZip(
        zip: ZipFile,
        entries: List<ZipEntry>,
        displayName: String,
        payloadDir: File,
    ): Collected {
        val files = LinkedHashSet<String>()
        val skipped = mutableListOf<String>()
        for (entry in entries) {
            var rel = norm(entry.name)
            if (rel.startsWith("__MACOSX/")) continue
            if (rel.lowercase().startsWith("mods/")) rel = rel.substring(5)
            if (put(zip, entry, payloadDir, rel)) files += rel else skipped += "unsafe path: $rel"
        }
        return Collected(displayName.substringBeforeLast('.'), files.toList(), skipped)
    }

    // ---------- helpers ----------

    private fun put(zip: ZipFile, entry: ZipEntry, payloadDir: File, rel: String): Boolean {
        if (rel.isEmpty() || rel.split('/').any { it.isEmpty() || it == ".." }) return false
        val dest = File(payloadDir, rel)
        if (!dest.canonicalPath.startsWith(payloadDir.canonicalPath + File.separator)) return false
        dest.parentFile?.mkdirs()
        zip.getInputStream(entry).use { i -> dest.outputStream().use { i.copyTo(it) } }
        return true
    }

    private fun norm(path: String) =
        path.replace('\\', '/').replace(Regex("/+"), "/").trim('/')

    private fun join(a: String, b: String) =
        listOf(a, b).filter { it.isNotBlank() }.joinToString("/")
}
