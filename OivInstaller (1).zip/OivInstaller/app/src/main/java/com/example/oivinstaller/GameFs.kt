package com.example.oivinstaller

import android.content.Context
import android.os.ParcelFileDescriptor
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/** Minimal file operations on the game's mods folder, either directly or through Shizuku. */
interface GameFs {
    fun exists(path: String): Boolean
    fun openRead(path: String): InputStream?
    fun openWrite(path: String): OutputStream
    fun delete(path: String): Boolean
    fun listDir(path: String): List<String>?
}

class LocalFs : GameFs {
    override fun exists(path: String) = File(path).exists()

    override fun openRead(path: String): InputStream? =
        File(path).takeIf { it.isFile }?.inputStream()

    override fun openWrite(path: String): OutputStream {
        val f = File(path)
        f.parentFile?.mkdirs()
        return f.outputStream()
    }

    override fun delete(path: String) = File(path).delete()

    override fun listDir(path: String): List<String>? = File(path).list()?.toList()
}

class ShizukuFs(private val svc: IFileService) : GameFs {
    override fun exists(path: String) = svc.exists(path)

    override fun openRead(path: String): InputStream? =
        svc.openRead(path)?.let { ParcelFileDescriptor.AutoCloseInputStream(it) }

    override fun openWrite(path: String): OutputStream {
        val pfd = svc.openWrite(path) ?: throw IOException("Can't open $path for writing")
        return ParcelFileDescriptor.AutoCloseOutputStream(pfd)
    }

    override fun delete(path: String) = svc.delete(path)

    override fun listDir(path: String): List<String>? = svc.list(path)?.toList()
}

object Backends {
    fun isProtected(path: String) =
        path.contains("/Android/data/") || path.contains("/Android/obb/")

    /** Picks Shizuku for Android/data paths and plain file access for everything else. */
    fun open(path: String): GameFs {
        if (!isProtected(path)) return LocalFs()
        val svc = ShizukuLink.service
            ?: throw IllegalStateException(
                "Shizuku isn't connected. Start Shizuku, allow this app, then try again.",
            )
        return ShizukuFs(svc)
    }
}

object Prefs {
    const val DEFAULT_MODS =
        "/storage/emulated/0/Android/data/com.thegwchr.fuzzy/files/game/mods"

    fun modsPath(ctx: Context): String =
        ctx.getSharedPreferences("settings", 0).getString("mods", DEFAULT_MODS) ?: DEFAULT_MODS

    fun setModsPath(ctx: Context, value: String) {
        ctx.getSharedPreferences("settings", 0).edit().putString("mods", value).apply()
    }
}
