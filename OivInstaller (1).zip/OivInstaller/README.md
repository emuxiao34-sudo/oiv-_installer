# OIV / ZIP Mod Installer (Android)

Installs `.oiv` and `.zip` mods into a game's `mods` folder, lets you switch each mod on and off,
and has a floating menu you can open over the game.

Default mods folder (change it in the app if yours differs):
`/storage/emulated/0/Android/data/com.thegwchr.fuzzy/files/game/mods`

## Build
Upload the project to GitHub and let the "Build APK" action build it (see the chat instructions),
or open the folder in Android Studio and choose Build > Build APK(s).

## First-time setup on the phone
1. Install and start **Shizuku** (Android 11+: turn on Wireless debugging, then start Shizuku from its app).
   Shizuku has to be started again after every reboot.
2. Open this app. Tap **Allow Shizuku access** and accept the prompt.
3. Tap **Allow overlay** (Display over other apps) so the floating menu can show.

## Use
- **Add mod**: pick an `.oiv` or `.zip`. The mod is saved inside the app and turned on straight away.
- **Switches**: turning a mod OFF puts the original game files back (or removes files the game never had).
  Turning it ON copies the mod's files in again.
- **Floating menu**: "Show floating menu" puts a draggable MODS bubble on screen. Tap it for the same
  switches while the game is running. Restart the game after changing mods.
- If two mods change the same file, the most recently turned-on one wins; turning it off falls back to the
  next one, then to the original.

## How it works
- `.oiv`: reads `assembly.xml`. Each `<add>` / `<replace>` goes to `<mods>/<archive path>/<target path>`,
  mirroring how OpenIV uses a `mods` folder (the `.rpf` is treated as a folder).
- `.zip` without `assembly.xml`: files keep their paths (a leading `mods/` is stripped).
- Writing into `Android/data` is done through a small file service that Shizuku runs for the app.
  Folders outside `Android/data` are written directly (needs "All files access").

## Limits
- Not supported (listed as "skipped"): `<delete>` and text/XML edit operations (`<text>`, `<xml>`, ...).
- The app never opens or edits `.rpf` archives.
- Untested: written without being compiled or run on a device. Send the build error or the on-screen
  message if something fails.
